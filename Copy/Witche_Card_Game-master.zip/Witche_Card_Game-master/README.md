# There a simple game card according to Gwent - Wicher Game Card. The rules is simple. You have to pick the same pairs of cards. Enjoy 
